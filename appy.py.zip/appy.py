import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import refinitiv.dataplatform.eikon as ek

app_key = '9b8ddd220e9145aeb7d0c34ec1aee644c4e6431a'
ek.set_app_key(app_key)


def calculate_market_share_change_interest_rate(identifier, N):
    # Create empty lists to store data
    dates = []
    market_shares = []
    interest_rates = []

    # Iterate over the entire range of N days
    for i in range(N):
        date = "-" + str(i)

        # Fetch historical data for the current date
        historical_data_stock, err = ek.get_data(
            instruments=[identifier],
            fields=['OPEN', 'CLOSE'],
            parameters={
                'SDate': '2024-01-01' ,
                'EDate': '2024-02-01' ,
                'Frq': 'D'
            })

        if len(historical_data_stock) == 0:
            print(f"No data available for {date}.")
            continue  # Skip if no data available for the current date

        # Check if required columns exist in the DataFrame
        if 'OPEN' not in historical_data_stock.columns or 'CLOSE' not in historical_data_stock.columns:
            print(f"Required columns not found in data for {date}.")
            continue

        # Extract open and close prices
        open_price = historical_data_stock.at[0, 'OPEN']
        close_price = historical_data_stock.at[0, 'CLOSE']

        # Calculate market share (close price / open price)
        market_share = close_price / open_price

        # Fetch interest rate data for the current date
        historical_data_interest, err = ek.get_data(
            instruments=['US2YT=RR'],  # Example: 2-year Treasury yield
            fields=['CLOSE'],
            parameters={
                'SDate':'2024-01-01' ,
                'EDate': '2024-02-01',
                'Frq': 'D'
            })

        if len(historical_data_interest) == 0:
            print(f"No interest rate data available for {date}.")
            continue  # Skip if no data available for the current date

        # Check if required columns exist in the DataFrame
        if 'CLOSE' not in historical_data_interest.columns:
            print(f"No 'CLOSE' column found in interest rate data for {date}.")
            continue

        # Calculate interest rate
        interest_rate = historical_data_interest.at[0, 'CLOSE']

        # Append data to lists
        dates.append(date)
        market_shares.append(market_share)
        interest_rates.append(interest_rate)

    # Convert lists to numpy arrays
    market_shares = np.array(market_shares).reshape(-1, 1)
    interest_rates = np.array(interest_rates).reshape(-1, 1)

    # Perform linear regression
    model = LinearRegression()
    model.fit(interest_rates, market_shares)
    predicted_market_shares = model.predict(interest_rates)

    # Calculate R-squared
    r_squared = r2_score(market_shares, predicted_market_shares)

    # Create DataFrame with results
    result_df = pd.DataFrame(
        {'Date': dates, 'Market_Share': market_shares.flatten(), 'Interest_Rate': interest_rates.flatten(),
         'Predicted_Market_Share': predicted_market_shares.flatten()})

    return result_df, r_squared


if __name__ == '__main__':
    identifier = input("Enter stock identifier (e.g., DFS.O): ")
    N = int(input("Enter the number of days for historical data: "))
    result_df, r_squared = calculate_market_share_change_interest_rate(identifier, N)
    print(result_df)
    print("Coefficient of determination (R-squared):", r_squared)
